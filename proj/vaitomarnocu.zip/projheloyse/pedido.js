// Preços das pizzas por sabor e tamanho
const precosPizza = {
    "Atum": { broto: 30, media: 35, grande: 40 },
    "Frango com Cheddar": { broto: 32, media: 37, grande: 42 },
    "Portuguesa": { broto: 34, media: 39, grande: 44 },
    "Calabresa": { broto: 30, media: 35, grande: 40 },
    "Calabresa Especial": { broto: 35, media: 40, grande: 45 },
    "Margueritta": { broto: 33, media: 38, grande: 43 },
    "Estrogonoff de Carne": { broto: 37, media: 42, grande: 47 },
    "Frango com Catupiry": { broto: 37, media: 42, grande: 47 }
};

// Variáveis para armazenar os dados de tamanho e sabores
let tamanhoSelecionado = null;
let saboresSelecionados = [];

// Atualiza o preço total com base nos sabores e no tamanho da pizza
function atualizarPrecoTotal() {
    let total = 0;

    // Se a pizza for grande e tiver mais de um sabor, segue a lógica do preço dobrado e dividido
    if (tamanhoSelecionado === "grande" && saboresSelecionados.length > 0) {
        // O primeiro sabor tem o preço cheio
        total += precosPizza[saboresSelecionados[0]][tamanhoSelecionado] * 2;

        // O segundo sabor tem o preço dividido por 2
        if (saboresSelecionados.length > 1) {
            total += precosPizza[saboresSelecionados[1]][tamanhoSelecionado] / 2;
        }
    } else {
        // Se não for grande, o preço é normal para 1 sabor
        saboresSelecionados.forEach(sabor => {
            if (precosPizza[sabor] && tamanhoSelecionado) {
                total += precosPizza[sabor][tamanhoSelecionado];
            }
        });
    }

    // Atualiza o valor total na página
    document.querySelector("#preco-total").textContent = total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Exibe os sabores selecionados na lista
function exibirSabores() {
    const lista = document.getElementById('lista-sabores');
    lista.innerHTML = ""; // Limpa a lista antes de adicionar

    // Adiciona os sabores à lista
    saboresSelecionados.forEach(sabor => {
        const li = document.createElement('li');
        li.textContent = sabor;

        // Botão de remover sabor
        const btn = document.createElement('button');
        btn.textContent = "Remover";
        btn.onclick = () => removerSabor(sabor);

        li.appendChild(btn);
        lista.appendChild(li);
    });
}

// Adiciona um sabor à comanda
function addToOrder(sabor) {
    if (!tamanhoSelecionado) {
        alert("Selecione o tamanho da pizza antes de adicionar sabores.");
        return;
    }

    const maxSabores = tamanhoSelecionado === "broto" ? 1 : 2;

    // Verifica se o número máximo de sabores foi atingido
    if (saboresSelecionados.length >= maxSabores) {
        alert(`Você só pode escolher até ${maxSabores} sabor(es) para uma pizza ${tamanhoSelecionado}.`);
        return;
    }

    // Adiciona o sabor à lista de sabores, se não estiver lá
    if (!saboresSelecionados.includes(sabor)) {
        saboresSelecionados.push(sabor);
        exibirSabores();
        atualizarPrecoTotal();
        verificarFinalizar();
    }
}

// Remove um sabor da comanda
function removerSabor(sabor) {
    saboresSelecionados = saboresSelecionados.filter(s => s !== sabor);
    exibirSabores();
    atualizarPrecoTotal();
    verificarFinalizar();
}

// Verifica se o pedido está pronto para ser finalizado
function verificarFinalizar() {
    const btn = document.getElementById("finalizar-pedido");
    if (tamanhoSelecionado && saboresSelecionados.length > 0) {
        btn.disabled = false;
    } else {
        btn.disabled = true;
    }
}

// Define o tamanho da pizza selecionado e atualiza a página
document.querySelectorAll('#tamanhos-pizza button').forEach(botao => {
    botao.addEventListener('click', () => {
        tamanhoSelecionado = botao.dataset.tamanho;
        document.getElementById('tamanho-pizza').textContent = tamanhoSelecionado.charAt(0).toUpperCase() + tamanhoSelecionado.slice(1);
        atualizarPrecoTotal();
        verificarFinalizar();
    });
});

// Função para finalizar o pedido
function finalizeOrder() {
    if (!tamanhoSelecionado || saboresSelecionados.length === 0) {
        alert("Por favor, selecione o tamanho e os sabores antes de finalizar o pedido.");
        return;
    }

    // Cria o objeto de pizza para adicionar à comanda
    const pizza = {
        tamanho: tamanhoSelecionado,
        sabores: saboresSelecionados.map(sabor => ({ sabor: sabor, preco: precosPizza[sabor][tamanhoSelecionado] })),
        preco: calcularPrecoTotal() // Calcula o preço total da pizza
    };

    // Recupera a comanda atual ou cria uma nova
    let comanda = JSON.parse(localStorage.getItem("comandaFinal")) || [];

    // Adiciona a pizza à comanda
    comanda.push(pizza);

    // Atualiza a comanda no localStorage
    localStorage.setItem("comandaFinal", JSON.stringify(comanda));

    // Exibe a comanda na tela de confirmação
    window.location.href = 'confirmacao.html';  // Redireciona para a página de confirmação
}

// Função para calcular o preço total
function calcularPrecoTotal() {
    let total = 0;
    saboresSelecionados.forEach(sabor => {
        total += precosPizza[sabor][tamanhoSelecionado];
    });
    return total;
}
