document.addEventListener("DOMContentLoaded", () => {
  const botoesTamanho = document.querySelectorAll(".btn-size");

  botoesTamanho.forEach(botao => {
      botao.addEventListener("click", () => {
          const tamanho = botao.dataset.tamanho;  // Obtém o tamanho do botão
          localStorage.setItem("tamanhoPizza", tamanho);  // Salva o tamanho da pizza no localStorage
          window.location.href = "pedido.html";  // Redireciona para a página de pedido
      });
  });
});
