// Recupera os dados da comanda do localStorage
const comanda = JSON.parse(localStorage.getItem('comandaFinal')) || [];

// Exibe os detalhes do pedido
const pedidoDetalhes = document.getElementById('pedido-detalhes');
pedidoDetalhes.innerHTML = ''; // Limpa antes de adicionar novos dados

if (comanda.length > 0) {
    comanda.forEach((pizza, index) => {
        const divPizza = document.createElement('div');
        divPizza.classList.add('pizza');

        const tamanho = pizza.tamanho.charAt(0).toUpperCase() + pizza.tamanho.slice(1);
        const preco = pizza.preco.toFixed(2);

        // Corrigido: pega os nomes dos sabores corretamente
        const listaSabores = pizza.sabores.map(obj => obj.sabor).join(', ');

        divPizza.innerHTML = `
            <h3>Pizza ${index + 1} - Tamanho: ${tamanho}</h3>
            <p><strong>Sabores:</strong> ${listaSabores}</p>
            <p><strong>Total da Pizza:</strong> R$ ${preco}</p>
        `;

        pedidoDetalhes.appendChild(divPizza);
    });

    // Exibe o total da comanda
    const totalComanda = comanda.reduce((total, pizza) => total + pizza.preco, 0);
    const container = document.getElementById('comanda-container');
    container.innerHTML += `
        <h3>Total da Comanda:</h3>
        <p><strong>Total: </strong>R$ ${totalComanda.toFixed(2)}</p>
    `;
} else {
    pedidoDetalhes.innerHTML = '<p>Não há pedidos na comanda.</p>';
}

// Geração do QR Code para PIX
function gerarQRCodePix() {
    const pixChaveAleatoria = Math.random().toString(36).substring(2, 15);
    const qrCodePix = document.getElementById('pix-qr-code');

    QRCode.toCanvas(qrCodePix, pixChaveAleatoria, function (error) {
        if (error) console.error(error);
        console.log('QR Code gerado com sucesso!');
    });
}

gerarQRCodePix();
